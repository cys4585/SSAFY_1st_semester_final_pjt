# Final Project - 영화 추천 페이지 만들기



## 1.  팀원 정보 및 업무 분담

- 최영수(팀장)

  - Server Side (Django)

  - Client Side 일부 (JS)

- 유보람(팀원)
  - Client Side (JS, HTML, CSS)



## 2. 목표 서비스 구현 및 실제 구현 정도

1) 목표 서비스

- 영화 정보 기반 추천 서비스 구성

- 커뮤니티 서비스 구성
- HTML, CSS, JavaScript, Vue.js, Django, REST API, DataBase 등을 활용한 실제 서비
  스 설계
- 서비스 관리 및 유지보수



2) 실제 구현

(1) 영화 정보 조회 

- 최신순, 인기순, 평점순 및 장르에 따른 영화 전체목록 조회 가능

- 각각의 영화에 대한 상세 정보조회와 '좋아요' 기능 및 평점을 포함한 리뷰기능 구현

  

(2) 영화 추천 서비스

- 사용자의 '좋아요', '리뷰'를 기반으로 하여 영화 추천 서비스 제작

- 사용자와 관련성 높은 영화데이터를 카드에 넣도록 설계. 이를 유저가 고르는 게임형식으로 구현

  

(3) 커뮤니티 서비스

- 영화 정보와 관련된 대화를 할 수 있는 커뮤니티 기능을 구현

- 로그인한 사용자만 글을 조회 / 생성 할 수 있으며 작성자 본인만 글을 수정/삭제 가능

- 사용자는 작성된 게시글에 댓글을 작성할 수 있어야 하며 작성자 본인만 댓글을 삭제 가능

  

(4) 계정 서비스

- 회원가입하여 로그인 한 사용자만 영화서비스를 이용가능하도록 구현
- 회원가입한 사용자는 회원탈퇴기능을 이용하여 유저정보 삭제 가능

- 사용자가 '좋아요', '리뷰'를 남긴 영화 데이터를 마이페이지에 저장하는  서비스 구현





## 3. ERD (Model)

![image-20210528001250525](README_Final Project.assets/image-20210528001250525.png)



## 4. API URL

1. movies app

![image-20210528002046948](README_Final Project.assets/image-20210528002046948.png)

2. community app

![image-20210528002059993](README_Final Project.assets/image-20210528002059993.png)

3. Accounts

![image-20210528002105565](README_Final Project.assets/image-20210528002105565.png)



## 5. 컴포넌트 구조

![image-20210527234946926](README_Final Project.assets/image-20210527234946926.png)







## 6. 필수 기능에 대한 설명

1) Account 

- Signup 

- Login

- Logout

- Signout

- My Movie List (Like base, Review base) 

  

2) Movie

- Movie List Read (전체 영화 조회, filtering(장르별), sorting(최신순, 인기순, 평점순)

- Movie Detail

- Movie Review CRUD

- Movie Like

- Movie Recommend

  

3)Community

- Post CRUD

- Post List Read
- Post Detail

- Post 좋아요

- Post Comment CRUD



## 7. 배포 서버 URL





## 8. 기타(느낀점)









